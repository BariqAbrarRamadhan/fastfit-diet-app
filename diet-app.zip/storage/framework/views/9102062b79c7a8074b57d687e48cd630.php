<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Program Diet & Olahraga Khusus Untuk Anda">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo $__env->yieldContent('title', 'Diet & Exercise App'); ?></title>

  <link rel="icon" href="<?php echo e(asset('icons/favicon.ico')); ?>" type="image/x-icon">

  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">

  <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
  <?php endif; ?>
  <?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="font-inter bg-white text-gray-900">

  
  <?php if(auth()->guard()->check()): ?>
    
  <?php endif; ?>

  
  <?php echo $__env->yieldContent('content'); ?>

  
  <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH D:\laragon\www\diet-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>